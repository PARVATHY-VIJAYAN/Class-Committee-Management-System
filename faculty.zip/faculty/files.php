<?php 
session_start();
include"header.php";?>
                  
<?php include 'topnav.php'; ?>

                <div class="container-fluid">

          

<?php    
    
 $files=mysqli_query($connection,"select distinct classcommittee, course_id, group_id,sch_date from file where fac_id='".$_SESSION['fac_id']."'  and status='n'");
        while($row=mysqli_fetch_assoc($files)){
                            
            $grp=mysqli_query($connection,"select name from group_details where group_id='".$row['group_id']."'");
                    while($roww=mysqli_fetch_assoc($grp))
                        $group=$roww['name'];

    ?>
                                <a class="dropdown-item d-flex align-items-center" href="uploadfiles.php?c=<?php echo $row['classcommittee'];?>&g=<?php echo $row['group_id'];?>&course=<?php echo $row['course_id'];?>">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                       <span class="font-weight-bold"><?php echo $group; ?></span>
                                        <div class="small text-gray-500">notification for file submission:<span class="font-weight-bold"><?php echo " ".$row['classcommittee'];?> </span><br>next meeting starts at <span class="font-weight-bold"><?php echo " ".$row['sch_date'];?></span></div>
                                        
                                        
                                        
                                    </div>
                                </a>
                        <?php } ?>
                </div>
   
<?php include "footer.php";?>

