<?php
include '../database.php';

?>
                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                   <?php
                    $cc=mysqli_query($connection, "select chair_id from cc_chair where fac_id ='".$_SESSION['fac_id']."' and dol='0000-00-00'");
                    while($row=mysqli_fetch_assoc($cc)){
                        $id=$row['chair_id'];
                    }
?>
                    <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown no-arrow mx-1">

                    <?php 
                    if(isset($id)){
                        echo"<br><a style='text-decoration:none; 'href='../Advisor/index.php'>go to advisor portal</a>";
                    } 
                    ?>
                       
                        </li>
                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">
                                    <?php
                                    date_default_timezone_set('Asia/Kolkata');
                                    $current_time= date('Y-m-d h:i:s', time());
                                    $threehrago = date('Y-m-d H:i:s', strtotime($current_time. ' + 12 hours'));
                                    $count=mysqli_query($connection,"select count(*)as count from file where fac_id='".$_SESSION['fac_id']."' and sch_date<'$threehrago' and status='n'");
        while($row=mysqli_fetch_assoc($count))
                        echo $row['count'];
        ?>
                                </span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                
<?php    
    
 $files=mysqli_query($connection,"select title,group_id,sch_date from file where fac_id='".$_SESSION['fac_id']."' and sch_date<'$threehrago' and status='n'");
        while($row=mysqli_fetch_assoc($files)){
                            
            $grp=mysqli_query($connection,"select name from group_details where group_id='".$row['group_id']."'");
                    while($roww=mysqli_fetch_assoc($grp))
                        $group=$roww['name'];

    ?>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                       <span class="font-weight-bold"><?php echo $group; ?></span>
                                        <div class="small text-gray-500">notification for file submission:<span class="font-weight-bold"><?php echo " ".$row['title'];?> </span><br>next meeting starts at <span class="font-weight-bold"><?php echo " ".$row['sch_date'];?></span></div>
                                        
                                        
                                        
                                    </div>
                                </a>
                        <?php } ?>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                        <!-- Nav Item - Messages --><li class="nav-item dropdown no-arrow mx-1">
                        
                            <a class="nav-link dropdown-toggle" 
                                 href="mails.php" aria-haspopup="true">
                                <i class="fas fa-envelope fa-fw"></i> 
                                <!-- Counter - Messages -->
                                    <?php
                                    $mails=mysqli_query($connection,"select count(*) as count from reminder where receiver_id='".$_SESSION['fac_id']."' and readmsg='n' order by id desc");
                                while($row=mysqli_fetch_assoc($mails)){
                                    if($row['count']!=0)
                                        echo '<span class="badge badge-danger badge-counter">'.$row['count'].'</span>';
                                }?>
                                
                        
                            </a>
                        </li>
                        <div class="topbar-divider d-none d-sm-block"></div>

                        <!-- Nav Item - User Information -->
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small">
                                <?php $fac_name=mysqli_query($connection,"select fac_name from faculty where fac_id='".$_SESSION['fac_id']."'");
                                            while($rw=mysqli_fetch_assoc($fac_name))
                                                echo $rw['fac_name'];
                                    ?></span>
                                <img class="img-profile rounded-circle"
                                    src="../images/fac_prof/<?php echo $_SESSION['fac_id'];?>.PNG">
                            </a>
                            <!-- Dropdown - User Information -->
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="userDropdown">
                                <a class="dropdown-item" href="profile.php">
                                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Profile
                                </a>
                                 <a class="dropdown-item" href="change_password.php">
                                    <i class="fas fa-key fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Password
                                </a>
                                <a class="dropdown-item" href="#">
                                    <i class="fas fa-info fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Faculty portal
                                </a>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="../faculty/login.php" >
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->