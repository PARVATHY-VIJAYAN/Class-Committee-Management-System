<?php 
session_start();
include"header.php";?>
                  
<?php include 'topnav.php'; ?>
                <div class="container-fluid mt-5">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Scheduled Meeting</h1>
                  
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Upcoming meeting list</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Starts at</th>
                                            <th>Ends by</th>
                                            <th>Join</th>
                                            
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
                                       $groups=mysqli_query($connection,"SELECT group_id FROM `class_instructors` where fac_id='".$_SESSION['fac_id']."'");
                                        while($row=mysqli_fetch_assoc($groups)){

                                        $gid=$row['group_id']; 
                                        $meeting=mysqli_query($connection,"select * from meeting where group_id='$gid' && end_datetime >= CURRENT_TIMESTAMP order by start_datetime");
                                        while($rows=mysqli_fetch_assoc($meeting)){
                                            
                                            echo"<form method='get'><tr>";
                                            echo"<td>".$rows['title']."</td>";
                                            echo"<td>".$rows['description']."</td>";
                                            echo"<td>".$rows['start_datetime']."</td>";
                                            echo"<td>".$rows['end_datetime']."</td>";
                                            echo"<td><button ";
                                            date_default_timezone_set('Asia/Kolkata');
                                            $current_time= date('Y-m-d h:i:s a', time());
                                            if(strtotime($current_time)<strtotime($rows['start_datetime']))
                                                echo" disabled class='btn btn-primary btn-user btn-block'>Join</button></td>";
                                            else{
                                            echo "class='btn btn-primary btn-user btn-block'><a style='color:white' target='blank' href='".$rows['link']."'>Join</a></button></td>";
                                            }
                                            
                                            echo"</tr></form>";

                                        }
                                        }
                                        
                                           ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
<?php include"footer.php";?>
