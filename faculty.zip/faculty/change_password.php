<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>change Password</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body class="">

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

              <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                               <div class="col-lg-6 d-none d-lg-block pt-5 pl-5">
                                <img src="img/forget.svg" width=400>
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-2">Change Your Password</h1>
                                        <p class="mb-4"> we'll send you a link to reset your password!</p>
                                    </div>
                                    <form class="user" method="post">
                                        <div class="form-group">
                                            <input type="email" class="form-control form-control-user"
                                                name="email" aria-describedby="emailHelp"
                                                placeholder="Enter Email Address...">
                                               
                                        </div>
                                        <input type="submit" name="submit" value=" Reset Password"class="btn btn-primary btn-user btn-block">
                                           
                                        
                                    </form>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>

  

<?php
    
       
               
           
session_start();
include "../database.php";
//insert contact

//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
require 'phpmail/PHPMailer.php';
require 'phpmail/SMTP.php';
require 'phpmail/Exception.php';
//Load Composer's autoloader


if(isset($_POST['email']) && isset($_POST['submit']))
 {
     $email=$_POST['email'];
     $sql = "select email from faculty where email='$email' and fac_id='".$_SESSION['fac_id']."'";
    $sql_run=mysqli_query( $connection, $sql );
    
while($row = mysqli_fetch_assoc($sql_run))          
  {
    $msg=$row['email'];
 
    $_SESSION['email']=$msg;

//Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);


    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'smtp.gmail.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'beenabijupersonal@gmail.com';                     //SMTP username
    $mail->Password   = 'jvwwmdzuqhpcvbnv';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
   
    $mail->setFrom('beenabijupersonal@gmail.com');
   

 

 
    $mail->addAddress($msg); 
     //Add a recipient
    //$mail->addAddress('ellen@example.com');               //Name is optional
   // $mail->addReplyTo('info@example.com', 'Information');
    //$mail->addCC('cc@example.com');
    //$mail->addBCC('bcc@example.com');
   $otp = rand(1000,9999);
 $_SESSION['otp']=$otp;
    $mail->isHTML(true);                                  //Set email format to HTML
  
$mail->Subject =  "Password Reset";
$mail->Body    = "Dear user, <br> Enter the below OTP for email validation .<b> ".$otp."</b><br> 
                 This is an automated email. Please do not reply to this email.";



    if($mail->send())
    {
        
          echo "<script>alert('mail successfully sent');</script>";
          ?>
        <script> location.replace("resetpassword.php"); </script>
        <?php
    }
   
}
}
    ?>
 <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>