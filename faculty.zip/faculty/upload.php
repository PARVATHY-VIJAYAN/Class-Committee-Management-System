<!DOCTYPE html><html lang="en"><head> <meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <meta name="description" content=""> <meta name="author" content=""> <title>Faculty portal</title> <!-- Custom fonts for this template-->
   

    
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
       <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css"> <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> <!-- Custom styles for this template--> <link href="css/sb-admin-2.css" rel="stylesheet"> 
       
       
<style>
    .batch-text:hover + .Extra-Text 
    {
    display: block;
    }
    .Extra-Text {
    margin-top: auto;
    width: 150px;
    border: 1px solid #000000;
    padding: auto;
    font-size: 12px;
    display: none;
    }
</style>
    <?php session_start();
    
    if(empty($_SESSION['fac_name']))
    {
        header("Location:login.php");
    }
    ?></head><body id="page-top"> <!-- Page Wrapper --> <div id="wrapper"> <!-- Sidebar --> <?php include 'sidebar.php';?> <!-- End of Sidebar --> <!-- Content Wrapper --> <div id="content-wrapper" class="d-flex flex-column"> <!-- Main Content --> <div id="content"> <!-- Topbar --> <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow"> <!-- Sidebar Toggle (Topbar) --> <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3"> <i class="fa fa-bars"></i> </button> <!-- Topbar Search --> <!-- Topbar Navbar --> <?php include 'topnav2.php'; 
    ?> <!-- End of Topbar --> <!-- Begin Page Content --> <div class="container-fluid"> <!-- Page Heading --> <div class="d-sm-flex align-items-center justify-content-between mb-4"> <h1 class="h3 mb-0 text-gray-800">MY UPLOADS</h1> </div><br><br>

   
   
   
<div class="row">
        <?php
        include "../database.php";
        $g=mysqli_query($connection,"select batch FROM batch where id IN (select DISTINCT batch_id from group_details where group_id IN (select  group_id from class_instructors where fac_id = '".$_SESSION['fac_id']."'))");
        while($g_row=mysqli_fetch_assoc($g))
        {?>
                    <?php
                    if(empty($_GET['batch']))
                    {
                    ?>
                    <div class="col-xs-6 pr-5">
                    
                        <a style="text-decoration: none;" href="http://localhost/CCMS/faculty/upload.php?batch=<?php echo $g_row['batch']?>">
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="align:center;">
                        <?php
                        echo substr($g_row['batch'],0,13);echo "...";
                        
                        ?>
                        </p>
                        </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $g_row['batch'];?>
                            </p>
                        </div>
                    </div>
                    <?php
                    }
        }
                    if(isset($_GET['batch'])&& isset($_GET['group'])&& isset($_GET['sem']) && isset($_GET['course_name']))
                    {
                        $_SESSION['course_name']=$_GET['course_name'];
                        
                       $q=mysqli_query($connection,"select * from file where fac_id = '".$_SESSION['fac_id']."' and group_id =(select group_id from group_details where name='".$_SESSION['group_name']."')  and course_id = (select course_id from course where course_name='".$_SESSION['course_name']."' and sem =".$_SESSION['sem']." )"); 
                       while($file_result=mysqli_fetch_assoc($q))
                       {
                           $of="../files/".$_SESSION['batch_name']."/".$_SESSION['group_name']."/".$_SESSION['sem']."/".$_SESSION['course_name']."/".$_SESSION['fac_id']."_".$_SESSION['fac_name']."/".$file_result['file_name'];
                            ?>
                            <div class="pr-3">
                                        <a href="<?php echo $of;?>">
                                        <?php
                                       if(preg_match("/\.docx\b/",$file_result['file_name']))
                                       {
                                    ?>

                                            <img src="https://download.logo.wine/logo/Microsoft_Word/Microsoft_Word-Logo.wine.png" width="90">

                                  <?php }
                                        else if(preg_match("/\.pdf\b/",$file_result['file_name']))
                                        {?>

                                        <img class="mt-1 mr-3" src="https://www.freeiconspng.com/thumbs/pdf-icon-png/pdf-word-icon-31.png" width="50">
                                        <?php 
                                        }
                                        else if(preg_match("/\.xlsx\b/",$file_result['file_name']))
                                        {?>

                                        <img class="mt-1" src="https://th.bing.com/th/id/R.5c4ec829490e04d5e33e2dc9d2b3c585?rik=J5TjjeSMKgHZ9A&riu=http%3a%2f%2fclipart-library.com%2fimages_k%2fexcel-icon-transparent%2fexcel-icon-transparent-2.png&ehk=lJ7PEFnVH72iv2al%2fiDjXB%2fVaLtJN%2bM2X6kujzNO7J8%3d&risl=&pid=ImgRaw&r=0" width="100">
                                        <?php 
                                        }
                                        else if(preg_match("/\.pptx\b/",$file_result['file_name']))
                                        {?>

                                        <img class="ml-3" src="https://th.bing.com/th/id/R.b9532431e6988c08319be83cec1c9601?rik=bvgcLQJGr2VGLA&riu=http%3a%2f%2fpluspng.com%2fimg-png%2fpng-powerpoint-microsoft-powerpoint-network-icon-image-483-2000.png&ehk=cMryyGjeMvTeeoGS3BQq3xWX2yFsvbcbxHjQoLGS85M%3d&risl=&pid=ImgRaw&r=0" width="55">
                                        <?php 
                                        }
                                        else 
                                        {?>

                                        <img class="mt-1 mr-2 ml-2" src="https://cdn2.iconfinder.com/data/icons/files-documents-13/128/file_txt_document_extension_files_text-512.png" width="50">
                                        <?php 
                                        }
                           
                                       echo $file_result['file_name'];?>
                                       </a>
                            </div>
                            <?php
                            
                       }
                        
                    }
                    else if(isset($_GET['batch'])&&isset($_GET['group'])&& isset($_GET['sem']))
                    {
                        $q = mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where fac_id=".$_SESSION['fac_id']." and group_id = (select group_id from group_details where name='".$_SESSION['group_name']."')) and sem = ".$_GET['sem']."");
                        
                        while($r=mysqli_fetch_assoc($q))
                        {
                            $course_name = $r['course_name'];?>
                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="http://localhost/CCMS/faculty/upload.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $_SESSION['group_name'];?>&sem=<?php echo $_SESSION['sem'];?>&course_name=<?php echo $course_name;?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo substr($course_name,0,13);
                            ?>
                            </p>
                            </a>
                            </div><?php
                        }
                        
                        
                    }
                    else if(isset($_GET['batch'])&&isset($_GET['group']))
                    {
                        $_SESSION['group_name']=$_GET['group']; 
                        
                        $q = mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where fac_id=".$_SESSION['fac_id']." and group_id = (select group_id from group_details where name='".$_SESSION['group_name']."'))");
                        
                        while($r=mysqli_fetch_assoc($q))
                        {
                            $sem = $r['sem'];
                            $_SESSION['sem']=$sem;
  ?>
                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="http://localhost/CCMS/faculty/upload.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $_SESSION['group_name'];?>&sem=<?php echo $sem;?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo "Semester : ";
                            echo substr($sem,0,13);
                            ?>
                            </p>
                            </a>
                            </div><?php
                            
                        }
                        
                    }
    
                    else if(isset($_GET['batch']))
                    {
                        $_SESSION['batch_name']=$_GET['batch'];
                        $batch_id =mysqli_query($connection,"select id from batch where batch ='". $_SESSION['batch_name']."'");
                        $batch_id_row=mysqli_fetch_assoc($batch_id);
                        $_SESSION['batch_id']=$batch_id_row['id'];
        
                        $find_group = mysqli_query($connection,"select * from group_details where batch_id = ".$batch_id_row['id']." AND group_id in (select group_id from class_instructors where fac_id =".$_SESSION['fac_id'].")");
                        while($find_group_row = mysqli_fetch_assoc($find_group))
                        {?>

                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="http://localhost/CCMS/faculty/upload.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $find_group_row['name'];?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo substr($find_group_row['name'],0,13);echo "...";
                            ?>
                            </p>
                            </a>
                            <div class="Extra-Text">
                                <p>
                                <?php echo $find_group_row['name'];?>
                                </p>
                            </div>
                            </div>
                    <?php
                    }
                }?>
</div>




