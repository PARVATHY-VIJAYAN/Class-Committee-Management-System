<!DOCTYPE html><html lang="en"><head> <meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <meta name="description" content=""> <meta name="author" content=""> <title>Faculty portal</title> <!-- Custom fonts for this template-->
   

    
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
       <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css"> <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> <!-- Custom styles for this template--> <link href="css/sb-admin-2.css" rel="stylesheet"> 
       
       
<style>
    .batch-text:hover + .Extra-Text 
    {
    display: block;
    }
    .Extra-Text {
    margin-top: auto;
    width: 150px;
    border: 1px solid #000000;
    padding: auto;
    font-size: 12px;
    display: none;
    }
</style>
    <?php session_start();
    
    if(empty($_SESSION['fac_name']))
    {
        header("Location:login.php");
    }
    ?></head><body id="page-top"> <!-- Page Wrapper --> <div id="wrapper"> <!-- Sidebar --> <?php include 'sidebar.php';?> <!-- End of Sidebar --> <!-- Content Wrapper --> <div id="content-wrapper" class="d-flex flex-column"> <!-- Main Content --> <div id="content"> <!-- Topbar --> <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow"> <!-- Sidebar Toggle (Topbar) --> <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3"> <i class="fa fa-bars"></i> </button> <!-- Topbar Search --> <!-- Topbar Navbar --> <?php include 'topnav2.php'; 
    ?> <!-- End of Topbar --> <!-- Begin Page Content --> <div class="container-fluid"> <!-- Page Heading --> <div class="d-sm-flex align-items-center justify-content-between mb-4"> <h1 class="h3 mb-0 text-gray-800">UPLOADED CHARTS</h1> </div><br><br>

   
   
   
<div class="row">
        <?php
        include "../database.php";
        $g=mysqli_query($connection,"select batch FROM batch where id IN (select DISTINCT batch_id from group_details where group_id IN (select  group_id from class_instructors where fac_id = '".$_SESSION['fac_id']."'))");
        while($g_row=mysqli_fetch_assoc($g))
        {?>
                    <?php
                    if(empty($_GET['batch']))
                    {
                    ?>
                    <div class="col-xs-6 pr-5">
                    
                        <a style="text-decoration: none;" href="classcharts.php?batch=<?php echo $g_row['batch']?>">
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="align:center;">
                        <?php
                        echo substr($g_row['batch'],0,13);echo "...";
                        
                        ?>
                        </p>
                        </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $g_row['batch'];?>
                            </p>
                        </div>
                    </div>
                    <?php
                    }
        }
                    if(isset($_GET['batch'])&& isset($_GET['group'])&& isset($_GET['sem']) && isset($_GET['course_name']))
                    {
                        
                        ?>
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        

                    
                   
                   
                   
                   
                    <?php 
                     $i=0;
                    $query_graph = mysqli_query($connection,"select * from graph where fac_id='".$_SESSION['fac_id']."' and  group_id= '".$_SESSION['group_id_f']."'");
                    while($row_graph=mysqli_fetch_assoc($query_graph))
                    {
                        $query_c = mysqli_query($connection,"select * from course where course_id= '".$row_graph['course_id']."'");
                        $row_c=mysqli_fetch_assoc($query_c);
                    ?>                 
                    <!--pie chart thing ... -->

                     <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
                        <script type="text/javascript">
                          google.charts.load('current', {'packages':['corechart']});
                          google.charts.setOnLoadCallback(drawChart);

                          function drawChart() {
                          //avarage mark *100 / outofmark 
                              <?php $avg_percentage = (($row_graph['totalmark']/$row_graph['count'])*100)/$row_graph['outof'];?>
                            var data = google.visualization.arrayToDataTable([
                              ['Task', 'Marks'],
                              ['Avarage', <?php echo $avg_percentage;?>],
                              [null,      <?php echo 100-$avg_percentage;?>]
                            ]);

                              var options = {
                              legend: {position: 'bottom'},
                              //pieSliceText: 'none',
                              pieStartAngle: 360,
                              tooltip: { trigger: 'none' },
                              slices: {
                                0: { color: '#1cc88a' },
                                1: { color: 'transparent' }
                              }
                            };
                            var chart = new google.visualization.PieChart(document.getElementById('piechart<?php echo $i?>'));

                            chart.draw(data,options);
                          }
                        </script>
                    <!-- tht thing ends here-->

                        <!-- Pie Chart -->
                        <div class="col-xl-4 col-lg-5">
                            <!-- Dropdown Card Example -->
                            <div class="card shadow mb-4">
                                <!-- Card Header - Dropdown -->
                                <div
                                    class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary"><?php echo $row_c['course_name'];?></h6>
                                    <a href="classcharts.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $_SESSION['group_name'];?>&sem=<?php echo $_SESSION['sem'];?>&course_name=<?php echo $row_c['course_name'];?>&g_id=<?php echo $row_graph['id']?>" role="button" aria-haspopup="true" aria-expanded="false">
                                            <i class="fas fa-trash fa-sm fa-fw text-gray-400"></i>
                                    </a>
                                </div>
                                <!-- Card Body -->
                                <div class="card-body">
                                   
                                    
                                    <div class="chart-pie pt-4 pb-2">
                                        
                                        <div id="piechart<?php echo $i?>" style="width:auto"></div>
                                        
                                    </div>
                                    <center><small><i><?php echo $row_graph['title'];?></i></small></center>
                                </div>
                            </div>                        
                        </div>
                     <!--add more chart here-->
  
                <?php $i++; 
                    }?>
                    </div>
                   <?php
                    if(isset($_GET['g_id'])){
                        $q_dlt = mysqli_query($connection,"DELETE FROM graph WHERE id=".$_GET['g_id']);
                        echo "<script> location.replace('classcharts.php?batch=".$_SESSION['batch_name']."&group=".$_SESSION['group_name']."sem=".$_SESSION['sem'].")</script>";

                    }
                    }
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                        
                    else if(isset($_GET['batch'])&&isset($_GET['group'])&& isset($_GET['sem']))
                    {
                        $q = mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where fac_id=".$_SESSION['fac_id']." and group_id = (select group_id from group_details where name='".$_SESSION['group_name']."')) and sem = ".$_GET['sem']."");
                        
                        while($r=mysqli_fetch_assoc($q))
                        {
                            $course_name = $r['course_name'];
                            $_SESSION['course_id_f']=$r['course_id'];?>
                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="classcharts.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $_SESSION['group_name'];?>&sem=<?php echo $_SESSION['sem'];?>&course_name=<?php echo $course_name;?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo $course_name;
                            ?>
                            </p>
                            </a>
                            </div><?php
                        }
                        
                        
                    }
                    else if(isset($_GET['batch'])&&isset($_GET['group']))
                    {
                        $_SESSION['group_name']=$_GET['group']; 
                        
                        $q = mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where fac_id=".$_SESSION['fac_id']." and group_id = (select group_id from group_details where name='".$_SESSION['group_name']."'))");
                        
                        while($r=mysqli_fetch_assoc($q))
                        {
                            $sem = $r['sem'];
                            $_SESSION['sem']=$sem;
  ?>
                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="classcharts.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $_SESSION['group_name'];?>&sem=<?php echo $sem;?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo "Sem : ";
                            echo $sem;
                            ?>
                            </p>
                            </a>
                            </div><?php
                            
                        }
                        
                    }
    
                    else if(isset($_GET['batch']))
                    {
                        $_SESSION['batch_name']=$_GET['batch'];
                        $batch_id =mysqli_query($connection,"select id from batch where batch ='". $_SESSION['batch_name']."'");
                        $batch_id_row=mysqli_fetch_assoc($batch_id);
                        $_SESSION['batch_id']=$batch_id_row['id'];
        
                        $find_group = mysqli_query($connection,"select * from group_details where batch_id = ".$batch_id_row['id']." AND group_id in (select group_id from class_instructors where fac_id =".$_SESSION['fac_id'].")");
                        while($find_group_row = mysqli_fetch_assoc($find_group))
                        {
                            $_SESSION['group_id_f']=$find_group_row['group_id'];
                            ?>
                            
                            <div class="col-xs-6 pr-5">
                            <a style="text-decoration: none;" href="classcharts.php?batch=<?php echo $_SESSION['batch_name'];?>&group=<?php echo $find_group_row['name'];?>">
                            <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                            <br><br>
                            <p class="batch-text" style="align:center;">
                            <?php
                            echo $find_group_row['name'];
                            ?>
                            </p>
                            </a>
                            <div class="Extra-Text">
                                <p>
                                <?php echo $find_group_row['name'];?>
                                </p>
                            </div>
                            </div>
                    <?php
                    }
                }?>
</div>




