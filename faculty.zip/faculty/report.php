<!DOCTYPE html><html lang="en"><head> <meta charset="utf-8"> <meta http-equiv="X-UA-Compatible" content="IE=edge"> <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"> <meta name="description" content=""> <meta name="author" content=""> <title>Faculty portal</title> <!-- Custom fonts for this template-->
   
    
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
       <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css"> <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> <!-- Custom styles for this template--> <link href="css/sb-admin-2.css" rel="stylesheet"> 
       
        <?php 
    include "../database.php";
        session_start();
    
    if(empty($_SESSION['fac_name']))
    {
        header("Location:login.php");
    }
    ?></head><body id="page-top"> <!-- Page Wrapper --> <div id="wrapper"> <!-- Sidebar --> <?php include 'sidebar.php';?> <!-- End of Sidebar --> <!-- Content Wrapper --> <div id="content-wrapper" class="d-flex flex-column"> <!-- Main Content --> <div id="content"> <!-- Topbar --> <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow"> <!-- Sidebar Toggle (Topbar) --> <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3"> <i class="fa fa-bars"></i> </button> <!-- Topbar Search --> <!-- Topbar Navbar --> <?php include 'topnav2.php'; 
    ?> <!-- End of Topbar --> <!-- Begin Page Content --> <div class="container-fluid"> <!-- Page Heading --> <div class="d-sm-flex align-items-center justify-content-between mb-4"> <h1 class="h3 mb-0 text-gray-800">REPORTS</h1> </div><br><br>

   
   <?php
    if(isset($_GET['upload']))
    {
        $q = mysqli_query($connection,"insert into file (title,date,sch_date,fac_id,course_id,group_id,file_name,mode) values ('".$_GET['r_title']."', CURRENT_TIMESTAMP,'','".$_SESSION['fac_id']."','".$_SESSION['r_course']."','".$_SESSION['r_group']."','".$_GET['uploadfile']."','y')");
        
      
       // $f = "../files/BCA Regular/BCA 2021/1/Cpp/22_Kavitha K.R/".basename($_FILES["uploadfile"]["name"]);
        //move_uploaded_file($_FILES["uploadfile"]["tmp_name"], $f);
        ?>
    <script>
        alert("file uploaded");</script>
          <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800"><?php echo $_GET['r_title'];?></h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Mark</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php


        require_once "Classes/PHPExcel.php";
$path="../files/BCA Regular/BCA 2021/1/Cpp/22_Kavitha K.R/Book1.xlsx";
$reader= PHPExcel_IOFactory::createReaderForFile($path);
$excel_Obj = $reader->load($path); 
        $worksheet=$excel_Obj->getSheet('0');
    
$lastRow = $worksheet->getHighestRow();
$colomncount = $worksheet->getHighestDataColumn();
$colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);    
	for($row=0;$row<=$lastRow;$row++){
		echo "<tr>";
		for($col=0;$col<=$colomncount_number;$col++){
                    if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()!="")
                    {
                        if($col==1)
                        {
                            if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()<20)
                            {
                                echo "<td bgcolor='pink'>";
                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                echo "</td>";
                            }
                            else
                            {
                            echo "<td bgcolor='lightgreen'>";
                            echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                            echo "</td>";
                            }

                        }
                        else
                        {
                            echo "<td>";
                            echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                            echo "</td>";
                        }
            }
		}
		echo "</tr>";
	}	
echo "</table>";

                                      /* $gid=$_SESSION['group_id']; 
                                        $meeting=mysqli_query($connection,"select * from meeting where group_id='$gid' && end_datetime < CURRENT_TIMESTAMP");
                                        while($rows=mysqli_fetch_assoc($meeting)){
                                            echo"<tr>";
                                            echo"<td>".$rows['title']."</td>";
                                            echo"<td>".$rows['description']."</td>";
                                            
                                       echo"</tr>";
                                        }*/
                                        
                                        ?>
                                    
                                       
                                    </tbody>
                                </table>
                                
        <?php
          $_SESSION['group_name']=null;
        $_SESSION['course_name']=null;
        $_SESSION['r_batch'] = null;
        $_SESSION['r_group'] = null;
        $_SESSION['r_course'] = null;
    }
    
    // Allow certain file formats
/*if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
  $uploadOk = 0;}*/
    if(empty($_GET['upload']))
    {
    ?>
   
   
   <form method="GET" action="report.php">
  
  
       
  <div class="form-row">
    <div class="form-group col-md-4">
      <label>Batch</label>
      <select name="r_batch" onchange="if (this.value) window.location.href=this.value" class="form-control">
        <option hidden ><?php if(isset($_GET['r_batch'])){ 
        $q = mysqli_query($connection,"select * from batch where id = ".$_GET['r_batch']);
        $r = mysqli_fetch_assoc($q); echo $r['batch'];   }?> </option>
        <?php 
          $batch = mysqli_query($connection,"select * FROM batch where id IN (select DISTINCT batch_id from group_details where group_id IN (select  group_id from class_instructors where fac_id = '".$_SESSION['fac_id']."'))");
          while($batch_row= mysqli_fetch_assoc($batch))
          {
          ?>
        <option value="report.php?r_batch=<?php echo $batch_row['id'];?>">
            <?php echo $batch_row['batch'];?> </option>
        <?php }
          
          ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label>Group</label>
       <select name="r_group" onchange="if (this.value) window.location.href=this.value"  class="form-control">
        <option hidden ><?php if(isset($_GET['r_group'])){ 
        $qq = mysqli_query($connection,"select * from group_details where group_id = ".$_GET['r_group']);
        $rr = mysqli_fetch_assoc($qq); echo $rr['name'];   }?> </option>
        <?php 
          $f_group = mysqli_query($connection,"select * from group_details where batch_id = ".$_GET['r_batch']." AND group_id in (select group_id from class_instructors where fac_id =".$_SESSION['fac_id'].")");
          while($group_row = mysqli_fetch_assoc($f_group))
          {
          ?>
          <option value="report.php?r_batch=<?php echo $_GET['r_batch'];?>&r_group=<?php echo $group_row['group_id'];?>"><?php echo $group_row['name'];?></option>
        <?php 
          }
          
          ?>
      </select>
    </div>
    <div class="form-group col-md-4">
      <label>Course</label>
      <select name="r_course" onchange="if (this.value) window.location.href=this.value"  class="form-control">
        <option hidden ><?php if(isset($_GET['r_course'])){ 
        $qqq = mysqli_query($connection,"select * from course where course_id = '".$_GET['r_course']."'");
        $rrr = mysqli_fetch_assoc($qqq); echo $rrr['course_name'];   }?> </option>
        <?php 
          $f_course =mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where fac_id=".$_SESSION['fac_id']." and group_id = ".$_GET['r_group'].")");
          while($row_course = mysqli_fetch_assoc($f_course))
          {
          ?>
          <option value="report.php?r_batch=<?php echo $_GET['r_batch'];?>&r_group=<?php echo $_GET['r_group'];?>&r_course=<?php echo $row_course['course_id']?>"><?php echo $row_course['course_name'];?></option>
        <?php 
          }
          
          ?>
      </select>
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-12">
      <label>Title</label>
      <input id="title"  type="text" class="form-control" required name="r_title" placeholder="eg. : Mid Term Lab Evaluation Report, End Semester Marksheet, ...">
    </div>
       </div>
       
  <div class="form-group">
    <label>Upload</label>
    <input type="file" accept="application/msexcel" class="form-control"  name="uploadfile">
    <small id="emailHelp" class="form-text text-muted">&#9432;&nbsp;Upload Excel files only.</small>

  </div>
       
       <?php 
       if(isset($_GET['r_batch']) && isset($_GET['r_group']) && isset($_GET['r_course']))
       {
           $_SESSION['r_batch']= $_GET['r_batch'];
           $_SESSION['r_group']= $_GET['r_group'];
           $_SESSION['r_course']=$_GET['r_course'];
       }
       
       ?>
  <button type="submit" name="upload" value="upload"class="btn btn-primary">Upload</button>
</form>
   <?php }?>
   
   <!-- Bootstrap core JavaScript--> <script src="vendor/jquery/jquery.min.js"></script> <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script> <!-- Core plugin JavaScript--> <script src="vendor/jquery-easing/jquery.easing.min.js"></script> <!-- Custom scripts for all pages--> <script src="js/sb-admin-2.min.js"></script> <!-- Page level plugins --> <script src="vendor/chart.js/Chart.min.js"></script> <!-- Page level custom scripts --> <script src="js/demo/chart-area-demo.js"></script> <script src="js/demo/chart-pie-demo.js"></script></body></html>