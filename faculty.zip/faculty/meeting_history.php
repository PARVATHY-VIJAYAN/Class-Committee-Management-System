<!DOCTYPE html>
<html lang="en">
<?php  session_start();
 include"header.php";?>


<body id="page-top" >



                <div class="container-fluid mt-5">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Meeting History</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Starting time</th>
                                            <th>Ended by</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php
                                        $groups=mysqli_query($connection,"SELECT group_id FROM `class_instructors` where fac_id='".$_SESSION['fac_id']."'");
                                        while($row=mysqli_fetch_assoc($groups)){
                                       $gid=$row['group_id']; 
                                        $meeting=mysqli_query($connection,"select * from meeting where group_id='$gid' && end_datetime < CURRENT_TIMESTAMP");
                                        while($rows=mysqli_fetch_assoc($meeting)){
                                            echo"<tr>";
                                            echo"<td>".$rows['title']."</td>";
                                            echo"<td>".$rows['description']."</td>";
                                            echo"<td>".$rows['start_datetime']."</td>";
                                            echo"<td>".$rows['end_datetime']."</td>";
                                            
                                       echo"</tr>";
                                        }
                                        }
                                        ?>
                                    
                                       
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

 

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
        aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
                    <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
                <div class="modal-footer">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <a class="btn btn-primary" href="login.html">Logout</a>
                </div>
            </div>
        </div>
    </div>

<?php include"footer.php";?>

</body>

</html>