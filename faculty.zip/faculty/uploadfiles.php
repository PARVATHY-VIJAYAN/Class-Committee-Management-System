<?php 
session_start();
include"header.php";?>
                  
<?php include 'topnav.php'; ?>

                <div class="container-fluid">
                <form action="" method="post" enctype="multipart/form-data">
               <?php
                    $f_title= mysqli_query($connection,"select title from file where fac_id='".$_SESSION['fac_id']."' and course_id='".$_GET['course']."' and group_id='".$_GET['g']."' and classcommittee='".$_GET['c']."'");
                    while($row=mysqli_fetch_assoc($f_title)){
                        ?>
                        <input hidden type="text" name="<?php echo $row['title'];?>" value='<?php echo $row['title'];?>'>
                        <label  for="" class="form-control"><?php echo $row['title'];?></label>
                        <input required class="form-control" type="file" class="form" name='<?php echo $row['title'];?>'>
                        <?php
                    }
                ?>
                <textarea name="issue" class="form-control"placeholder="any issue" id="" cols="30" rows="10"></textarea>

                <input type="submit" class="form" name="upload">
                </form>
            
   
<?php include "footer.php";?>

<?php
$batch=mysqli_query($connection,"select batch from batch where id=(select batch_id from group_details where group_id='".$_GET['g']."')");
while ($row=mysqli_fetch_assoc($batch)){
    $b=$row['batch'];
}
$group=mysqli_query($connection,"select name from group_details where group_id='".$_GET['g']."'");
while ($row=mysqli_fetch_assoc($group)){
    $g=$row['name'];
}
$sem=mysqli_query($connection,"select sem,course_name from course where course_id='".$_GET['course']."'");
while ($row=mysqli_fetch_assoc($sem)){
    $s=$row['sem'];
    $c=$row['course_name'];
}
 $title=[];                   
foreach ($_POST as $k=>$v){
    if($k!='upload' && $k!='issue'){
        array_push($title,$v);
    }
}
$t=0;                 
if(isset($_POST['upload'])){
$target_path = "../file/$b/$g/$s/$c/".$_SESSION['fac_id']."_".$_SESSION['fac_name']."/"; 
foreach ($_FILES as $file)
{ 
    
    $uploaded=  move_uploaded_file($file["tmp_name"],$target_path.$file['name']);
   
    if($uploaded){
         $updatefiledb=mysqli_query($connection, "update file set file_name='".$file['name']."' , issue='".$_POST['issue']."', status='y' where classcommittee='".$_GET['c']."' and group_id='".$_GET['g']."' and course_id='".$_GET['course']."' and  title='".$title[$t]."'");
        $t=$t+1;
        ?><script>alert("uploaded successfully");</script><?php
         $file="";
    }
    $uploaded=0;
}
       
}
?>
    </div>
