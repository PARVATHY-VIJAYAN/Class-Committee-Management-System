<?php 
session_start();
include"header.php";?>
                  
<?php// include 'topnav.php'; ?>

                <div class="container-fluid">

                    <div class="card shadow mt-5 mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Mails</h6>
                        </div>
                    <div class="card-body">
                            <li >
                            
                            <!-- Dropdown - Messages -->
                            
                                
                                <?php $mails=mysqli_query($connection,"select * from reminder where receiver_id='".$_SESSION['fac_id']."' order by id desc");
                                while($row=mysqli_fetch_assoc($mails)){
                                    
    ?>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="dropdown-list-image mr-3">
                                        <img style="width:50px;border-radius:50%;" src="
                                           <?php 
                                            $cc_fac=mysqli_query($connection,"select fac_id from cc_chair where chair_id='".$row['sender']."'");
                                            while($rw=mysqli_fetch_assoc($cc_fac))
                                                $fac=$rw['fac_id'];
                                             $path='../images/fac_prof/'.$fac.'.png';
                                             
                                             if(file_exists($path)){
                                            echo $path;
                                            }
                                             else echo "../images/fac_prof/default.png";
                                            ?>
                                            ">
                                        <div class="status-indicator bg-success"> </div>
                                    </div>
                                    <div><?php $fac_name=mysqli_query($connection,"select fac_name from faculty where fac_id='$fac'");
                                            while($rw=mysqli_fetch_assoc($fac_name))
                                                $facn=$rw['fac_name'];
                                    ?>
                                        <div class="text-truncate"><?php echo "<b>".$facn."</b>"." <br> ".$row['description'];?></div>
                                        <div class="small text-gray-500"><?php echo $row['date'];
                                            if ($row['readmsg']=='n')
                                            echo '<i class="fa fa-circle" style="color:blue"></i>';
                            $read=mysqli_query($connection,"UPDATE `reminder` SET `readmsg` = 'y' WHERE `reminder`.`id` = '".$row['id']."';");?>
                                           </div>
                                            
                                    </div>
                                </a>
                                <?php } ?>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Read More Messages</a>
                        </li>
                    
                    </div>

                </div>               
                
                </div>
<?php include "footer.php";?>
