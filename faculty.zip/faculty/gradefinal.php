<?php 
session_start();
include"header.php";?>
                  

                <div class="container-fluid">

                         <h1 class="h3 mb-2 text-gray-800">GRADES</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary"></h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                     <form action="" method="post" enctype="multipart/form-data">

            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>O</th>
                        <th>A+</th>
                        <th>A</th>
                        <th>B+</th>
                        <th>B</th>
                    </tr>
                </thead>
                   <tbody>
                    <tr>
                        <td><input required type="text" value='100'  class="form col-md-6" name='of'><input required type="text" value='91' class="form-group col-md-6"  name='ot'></td>
                        <td><input required type="text" value='90'class="form-group col-md-6" name='apf'><input required value='81' type="text" class="form-group col-md-6"name='apt'></td>
                        <td><input required type="text" value='80'class="form-group col-md-6" name='af'><input required value='71'type="text" class="form-group col-md-6" name='at'></td>
                        <td><input required type="text" value='70' class="form-group col-md-6" name='bpf'><input required value='61'type="text" class="form-group col-md-6" name='bpt'></td>
                        <td><input required type="text" value='60'class="form-group col-md-6" name='bf'><input required value='51'type="text" class="form-group col-md-6" name='bt'></td>
                     </tr>
                </tbody>
                   <thead>
                    <tr>
                        <th>C</th>
                        <th>D</th>
                        <th>F</th>
                        <th>FA</th>
                    </tr>
                </thead>
                
                <tbody>
                       <tr>
                        <td><input required type="text" value='50' class="form-group col-md-6" name='cf'><input required type="text" value='41' class="form-group col-md-6" name='ct'></td>
                        <td><input required type="text" value='40'class="form-group col-md-6" name='df'><input required type="text" value='31'class="form-group col-md-6" name='dt'></td>
                        <td><input required type="text" value='30' class="form-group col-md-6" name='ff'><input required type="text" class="form-group col-md-6" value='0' name='ft'></td>
                        <td><input required type="text" value='75' class="form-group col-md-10" name='fa'></td>
                    </tr>
                </tbody>
                
            </table>
                       <label  for="" class="form-control">upload tentative grade(xml)</label>
                        <input required class="form-control" type="file" class="form" name='gradesheet'>
                        <input type="submit" name="upload" value="upload">
                        </form>   
            
                            </div>
                        </div>
                    </div>

                </div>
<?php
$g_table=mysqli_query($connection,"select * from grade_finalizationcc where id='".$_GET['id']."'");
    while ($roww=mysqli_fetch_assoc($g_table)){
        $batch=mysqli_query($connection,"select batch from batch where id=(select batch_id from group_details where group_id='".$roww['group_id']."')");
        while ($row=mysqli_fetch_assoc($batch)){
            $b=$row['batch'];
        }
        $group=mysqli_query($connection,"select name from group_details where group_id='".$roww['group_id']."'");
        while ($row=mysqli_fetch_assoc($group)){
            $g=$row['name'];
        }
        $sem=mysqli_query($connection,"select sem,course_name from course where course_id='".$roww['course_id']."'");
        while ($row=mysqli_fetch_assoc($sem)){
            $s=$row['sem'];
            $c=$row['course_name'];
        }
    }

if(isset($_POST['upload'])){

$target_path = "../file/$b/$g/$s/$c/".$_SESSION['fac_id']."_".$_SESSION['fac_name']."/"; 
$file=$_FILES['gradesheet'];
$updategrades=mysqli_query($connection, "update grade_finalizationcc set tentative_grade_report='".$file['name']."', o='".$_POST['ot']."', ap='".$_POST['apt']."', a='".$_POST['at']."', bp='".$_POST['bpt']."', b='".$_POST['bt']."', c='".$_POST['ct']."', d='".$_POST['dt']."', f='".$_POST['ff']."', fa='".$_POST['fa']."' where id='".$_GET['id']."'");
        $uploaded=  move_uploaded_file($file["tmp_name"],$target_path.$file['name']);
    if($uploaded){
        ?><script>alert("successfully uploaded");
                    location.replace("index.php");            
        </script>
        <?php
        
    }
}

?>
   
<?php include "footer.php";?>
















































