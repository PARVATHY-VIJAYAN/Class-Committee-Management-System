<?php 
session_start();
include"header.php";?>
                  
<?php include 'topnav.php'; ?>

                <div class="container-fluid">

        <!-- Outer Row -->
        <div class="row justify-content-center">

              <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <?php $fac=mysqli_query($connection,"select fac_name,fac_id,email from faculty where fac_id='".$_SESSION['fac_id']."'");
                                            while($row=mysqli_fetch_assoc($fac)){
                                            $name=$row['fac_name'];
                                            $id=$row['fac_id'];
                                            $email=$row['email'];
                                            }?>
                        <div class="row">
                               <div class="col-lg-6 d-none d-lg-block pt-5 pl-5">
                               <img style="width:200px;height:200px;border-radius:50%;" src="
                                           <?php 
                                            
                                             $path='../images/fac_prof/'.$id.'.PNG';
                                             
                                             if(file_exists($path)){
                                            echo $path;
                                            }
                                             else echo "../images/fac_prof/default.PNG";
                                            ?>
                                            ">
                                <form  method="POST" enctype="multipart/form-data">
                                     <input type="file" name="image" accept="image/*" />
                                    <button type="submit" name="file">Upload</button>
                                </form>
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-2">My Profile</h1>
                                    </div>
                                    <form class="user" method="post">
                                        <div class="form-group">
                                          
                                           <label class="form-control" for=""><?php echo $name;?></label>
                                           
                                                <label for="" class="form-control"><?php echo $id;?></label>
                                                
                                                <input type="email" class="form-control form-control-user"
                                                name="email"<?php if (isset($email))echo "value='".$email."'";?> aria-describedby="emailHelp"
                                                placeholder="Enter Email Address...">
                                            
                                        </div>
                                        <input type="submit" name="submit" value=" Reset email"class="btn btn-primary btn-user btn-block">
                                           
                                        
                                    </form>
                                   
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
          
                </div>
   <?php

if(isset($_POST['submit'])){
        $udateemail= mysqli_query($connection,"UPDATE `faculty` SET `email` = '".$_POST['email']."' WHERE `faculty`.`fac_id` = '".$_SESSION['fac_id']."'"); 
    if($udateemail){
        ?><script> location.replace("profile.php"); </script><?php
    }
    }
?>



<?php
if(isset($_POST['file'])){
// Get reference to uploaded image
    
     if(file_exists("../images/fac_prof/". $_SESSION['fac_id'].".PNG")){
            unlink("../images/fac_prof/". $_SESSION['fac_id'].".PNG");  
    }
    $image_file = $_FILES["image"];

        move_uploaded_file($image_file["tmp_name"],"../images/fac_prof/".$_SESSION['fac_id'].".PNG");
    
    $image_file="";
    ?> <script>location.replace("profile.php");</script><?php

}

?>
<?php include "footer.php";?>

