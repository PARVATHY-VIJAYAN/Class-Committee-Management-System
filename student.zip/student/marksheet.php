<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Student portal</title>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body id="page-top">
    <?php
    
        include '../database.php';

        session_start();
        if(empty($SESSION['roll']) && empty($_SESSION['password']) && $_SESSION['email']=="" )
        {
            header("location:login.php");
        }
        
        $query = "select * from student where stud_id =".$_SESSION['roll'];
        $result = mysqli_query($connection,$query);
        $row = mysqli_fetch_array($result);
        
        
    ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search -->
             
                    

                    <!-- Topbar Navbar -->
                    <?php include 'topnav.php'; ?>
                    <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Marksheet</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                    
                    
                   <?php 
                        $q = mysqli_query($connection,"select * from course where course_id = '".$_GET['g_course']."'"); 
                        $row_qq = mysqli_fetch_assoc($q);
                        $fac_query =mysqli_query($connection,"select * from faculty where fac_id ='".$_GET['fac_id']."';");
                        $row_find_fac = mysqli_fetch_assoc($fac_query);
                        
                        ?>
                        
                    
                   
                   <!-- Begin Page Content -->
                    <div class="container-fluid">
                    
                    <!-- Page Heading -->
                    <?php 
                        $title_query= mysqli_query($connection,"select * from file where fac_id='".$_GET['fac_id']."' and course_id='".$_GET['g_course']."' and group_id='".$_SESSION['group_id']."'");
                        $row_title = mysqli_fetch_assoc($title_query);
                        ?>
                    <p class="mb-2 text-gray-800"><?php echo $row_title['title'];?></p>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <tbody>
                                        <?php
                                            require_once "Classes/PHPExcel.php";                 
                                           $path="../file/".$_SESSION['batch_name']."/".$_SESSION['group_name']."/".$_SESSION['sem']."/".$row_qq['course_name']."/".$_GET['fac_id']."_".$row_find_fac['fac_name']."/". $_GET['f_name'];
                                            $reader= PHPExcel_IOFactory::createReaderForFile($path);
                                            $excel_Obj = $reader->load($path); 
                                            $worksheet=$excel_Obj->getSheet('0');
                                            $lastRow = $worksheet->getHighestRow();
                                            $colomncount = $worksheet->getHighestDataColumn();
                                            $colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);
                                            $pass = array();
                                            $fail = array();
                                            $absent= array();
                                            for($row=0;$row<=$lastRow;$row++)
                                            {
                                                echo "<tr>";
                                                for($col=0;$col<=$colomncount_number;$col++)
                                                {
                                                        if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()!="")
                                                        {
                                                            //finding outoff
                                                            if($col==2&&$row==1)
                                                            {
                                                                $outoff = substr($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue(),5);
                                                                echo "<th>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</th>";
                                                                
                                                            }
                                                            else if($col==0&&$row==1 || $col==1&&$row==1)
                                                            {
                                                                echo "<th>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</th>";
                                                                
                                                            }
                                                            else if($col==0 || $col==1)
                                                            {
                                                                 echo "<td>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</td>";
                                                            }
                                                            else
                                                            {
                                                                //ab
                                                                if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="ab"||$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="a"||$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="A")
                                                                {
                                                                     array_push($absent,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue());
                                                                    echo "<td bgcolor='#b3e6ff'>";                            
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }
                                                                //below 20 %
                                                                else if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()<=(($outoff*20)/100))
                                                                {
                                                                    array_push($fail,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue());
                                                                    
                                                                    echo "<td bgcolor='#ffcccc'>";                            
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }
                                                                //above 90 %
                                                                else if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()>=(($outoff*90)/100))
                                                                {
                                                                array_push($pass,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue());
                                                                    
                                                                echo "<td bgcolor='#bbff99'>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</td>";
                                                                }
                                                                else
                                                                {
                                                                    echo "<td>";
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }

                                                            }
                       
                                                        }
		                                      }
		                                      echo "</tr>";
                                            }	?>
                   
                                    </tbody>
                                    </table>
                                </div>
                                   <!-- list out students above 90%-->
                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Students who got above 90%</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                                <th>Mark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($pass);$i=$i+3)
                                         {
                                             echo "<tr><td>".$pass[$i]."</td><td>".$pass[$i+1]."</td><td>".$pass[$i+2]."</td></tr>";
                                         }?>
                                        </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                                    
                                    
                                    <!-- list out students below 20%-->

                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Students who got below 20%</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                                <th>Mark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($fail);$i=$i+3)
                                         {
                                             echo "<tr><td>".$fail[$i]."</td><td>".$fail[$i+1]."</td><td>".$fail[$i+2]."</td></tr>";
                                         }
                                        ?>
                                           </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                                    
                                    <!-- absentees-->
                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Absentees</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($absent);$i=$i+2)
                                         {
                                             echo "<tr><td>".$absent[$i]."</td><td>".$absent[$i+1]."</td></tr>";
                                         }?>
                                        </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                            </div>     
                            
                    </div>
                                   
                     

                     
                <!-- /.container-fluid -->
                
                        

</div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

  
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>