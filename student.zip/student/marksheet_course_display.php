<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Marksheet</title>
    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">
</head>
<body id="page-top">
    <?php
        include '../database.php';
        session_start();
        if(empty($SESSION['roll']) && empty($_SESSION['password']) && $_SESSION['email']=="" )
        {
            header("location:login.php");
        }
        $query = "select * from student where stud_id =".$_SESSION['roll'];
        $result = mysqli_query($connection,$query);
        $row = mysqli_fetch_array($result);
        
    ?>
    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php include 'sidebar.php';?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>

                    <!-- Topbar Search --

                    <!-- Topbar Navbar -->
                    <?php include 'topnav.php'; ?>
                    <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Courses</h1>
                    </div>

                    <!-- Content Row -->
                    <div class="row">
                    
                   <?php
                        
                        
                        $display_course = mysqli_query($connection,"select * from course where course_id in (select course_id from class_instructors where group_id = ".$_SESSION['group_id'].")");
                        
                        while($row_display_course = mysqli_fetch_assoc($display_course))
                        {
                        
                                    ?>

                                 <?php 
                                    if(empty($_GET['g_course']))
                                    {?>
                                      
                                      
                                         <!-- main file content -->

                                        <div class="card ml-2 mr-2" style="width:auto;height:auto;background:none;border:none">
                                        <div class="text-xs font-weight-bold text-warning text-uppercase mb-1"  style="width: auto;height: auto;text-align:center">
                                            <a style="text-decoration: none; color: black;" href="marksheet_course_display.php?g_course=<?php echo $row_display_course['course_id'];?>">
                                          <img  src="https://pngimg.com/d/folder_PNG8764.png" width="80">
                                       </a>
                                       </div>
                                           <small style="text-align:center;"><?php echo $row_display_course['course_name'];?></small>
                                        </div>
                                      
                                      <!--
                                       <div class="col-md-1">
                                                      <a style="text-decoration: none; color: black;" href="marksheet_course_display.php?g_course=<?php //echo $row_display_course['course_id'];?>">
                                                           <div class="row">
                                                               <img  src="https://pngimg.com/d/folder_PNG8764.png" width="80">
                                                           </div>
                                                            <div class="row">
                                                                <small style="text-align: center;"><?php //echo $row_display_course['course_name'];?></small>
                                                           </div>
                                                       </a>
                                         </div>-->
                                           <?php 
                                    }
                        }
                        
                        if(isset($_GET['g_course']))
                        {?>
                           
                              <ul>
                             <?php
                              //files of a group ..visible only forstudents
                              $query_file = mysqli_query($connection,"select * from file where group_id = ".$_SESSION['group_id']." and mode='y' and status='y' and course_id = '".$_GET['g_course']."'");
                              
                            ?>
                            <?php
                              while($row_query_file=mysqli_fetch_assoc($query_file)){
                              ?>
                                  
                                  
            
                                 
                                          <!-- finding the file type to display respective file icon -->
                                           <?php 
                                            if(preg_match("/\.xlsx\b/",$row_query_file['file_name']))
                                            {?>
                                                           <a style="text-decoration: none; color: black;" href="marksheet.php?g_course=<?php echo $_GET['g_course'];?>&f_name=<?php echo $row_query_file['file_name'];?>&fac_id=<?php echo $row_query_file['fac_id'];?>">
                                                                <li>
                                                                   <h6 class="m-0 font-weight-bold text-primary">
                                                                    <?php echo $row_query_file['title']?>
                                                                   </h6>

                                                                        <!--finding who is uploaded these file-->
                                                                    <?php $query_fac_name = mysqli_query($connection,"select * from faculty where fac_id = '".$row_query_file['fac_id']."'");
                                                                    $row_fac_name = mysqli_fetch_assoc($query_fac_name);
                                                                    ?>
                                                                    <i style='font-size:10px'>published by: <?php echo $row_fac_name['fac_name']."<br>Date : ".$row_query_file['date'];?></i>
                                                                </li>
                                                            </a>
                                                   
                                       <?php }?>
                                
                                   <?php 
                              }
                            ?>
                            </ul>
                        <?php
                              
                        }
                        
                      
                        ?>
                                   
                     
            
            
                     
                <!-- /.container-fluid -->

</div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

   

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>