<!DOCTYPE html>
<html lang="en">

<head>
    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
<style>
    @media (min-width: 1025px) {
.h-custom {
height: 100vh !important;
}
}
    </style>

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body>

    <!-- Page Wrapper -->
    <div id="wrapper">
        <!-- Sidebar -->
        <?php include '../database.php';?>

<?php  session_start();?>
<section class="h-220 w-100" style="background-color: #8fc4b7;">
  <div class="container py-5 h-50">
    <div class="row d-flex justify-content-center align-items-center h-50">
      <div class="col-lg-8 col-xl-6">
        <div class="card rounded-3">
          
          <div class="card-body p-3 p-md-5">
            <h3 class="mb-4 pb-2 pb-md-0 mb-md-5 px-md-5"><center>Registration</center></h3>

            <form method="POST"class="px-md-2">
                  
<div class="form-outline ">
    <label class="form-label" for="form3Example1q">Name</label>
    
    <input type="text" name="name" id="form3Example1q" class="form-control" />
</div>
                
<div class="form-outline ">
    <label class="form-label" >Reg.ID</label>

    <input type="text" name="id" class="form-control" />
</div>

<div class="row">
    <div class="col">

        <div class="form-outline datepicker">
            <label   class="form-label">Password</label>
            
            <input type="password" name="pass" class="form-control"   />
        </div>
    </div>
     <div class="col">

        <div class="form-outline datepicker">

            <label   class="form-label">Confirm password</label>

            <input type="password" name="cpass" class="form-control"   />

        </div>
    </div>
</div>
                  
<div class="form-outline datepicker">
    <label  class="form-label">Email</label>
    <input type="email" name="email" class="form-control"   />
</div>

<div class="row">
    <div class="col">
        <select name="batch" class="form-control select">
        <option value="1" >Batch</option>
        <?php
          $batch=mysqli_query($connection,"select * from batch");
          while($row=mysqli_fetch_assoc($batch)){
              $id=$row['id'];
              $batchh=$row['batch'];
              echo"<option value='$id'>$batchh</option>";

          }
          ?>
          
        </select>
    </div>


    <div class="col">

        <select name="year" class="form-control select">
        <option value="1" hidden >Year</option>
        <?php
          $year=mysqli_query($connection,"select distinct year from group_details");
          while($row=mysqli_fetch_assoc($year)){
              
              echo"<option value='".$row['year']."'>".$row['year']."</option>";

          }
        ?>
        </select>

    </div>
</div>

     

              <button type="submit" name="submit" class=" form-control btn btn-success btn-lg mt-3">Submit</button>

            </form>

          </div>
       
      </div>
    </div>
  </div>
  <?php
      if(isset($_POST['submit'])){
          if($_POST['name']!=""&&$_POST['id']!=""&&$_POST['pass']!=""&&$_POST['cpass']!=""&&$_POST['email']!=""&&$_POST['batch']!=""&&$_POST['year']!=""){
              
              
              
              $check = mysqli_query($connection ,"select count(*) from student where stud_id ='".$_POST['id']."'");
              $row_check = mysqli_fetch_assoc($check);
              if($row_check[0]<=0)
              {
                  header("location:login.php");
              }
              
                  
                  
                  if($_POST['pass']==$_POST['cpass']){
                    $sid=$_POST['id'];
                    $name=$_POST['name'];
                    $email=$_POST['email'];
                  $pass=$_POST['pass'];
                    $batch=$_POST['batch'];
                    $year=$_POST['year'];
                    $grp=mysqli_query($connection,"select group_id from group_details where batch_id='$batch' && year='$year'");
          while($row=mysqli_fetch_assoc($grp)){
              
              $group=$row['group_id'];

          }
                  $insert=mysqli_query($connection,"INSERT INTO `student` (`stud_id`, `name`, `group_id`, `password`, `email`, `batch`, `year`,`access`) VALUES ('$sid', '$name', '$group', '$pass', '$email', '$batch', '$year','deny');");
                  if($insert){
                      ?><script>
                        alert("registration successfull");
                        location.replace("login.php");
                        </script>
                      <?php
                      
                  }
                  else{
                      ?><script>
                        alert("registration failed!");
                        //location.replace("login.php");
                        </script>
                      <?php
                  }
              }
              else{
          ?><script>
                        alert("Password missmatch");
                        </script>
                      <?php
      }
          }
          else{
              ?><script>
                        alert("Please provide all necessary information.");
                        </script>
                      <?php
          }
      }?>