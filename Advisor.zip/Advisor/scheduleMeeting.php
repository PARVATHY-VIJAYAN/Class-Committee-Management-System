<?php  session_start();
 include"header.php";


       function addtofilestb($connection,$file,$current_time, $sdatetime, $f_id, $course, $group_id,$vmode,$cc){
        $filetble=mysqli_query($connection,"INSERT INTO `file` 
        (`id`, `title`,  `date`, `sch_date`, `fac_id`, `course_id`, `group_id`, `status`, `file_name`, `mode`, `classcommittee`) 
        VALUES (NULL, '$file',  '$current_time', '$sdatetime', '$f_id', '$course', '$group_id', 'n', '', '$vmode','$cc');");
        }
?>


                <div class="container-fluid mt-5">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Schedule Meeting </h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">DataTables Example</h6>
                        </div>
                        <div class="card-body">
<form method="post" id="myform">

<div class="row">
    <div class="col">
 Title
 
  <div class="mb-2">
<select name="title" class="form-control" id="">
    <option value="Zeroth class committee meeting">Zeroth class committee meeting</option>
    <option value="First class committee meeting">First class committee meeting</option>
    <option value="Midterm class committee meeting">Midterm class committee meeting</option>
    <option value="Internal finalization class committee meeting">Internal finalization class committee meeting</option>
    <option value="Grading finalization class committee meeting">Grading finalization class committee meeting</option>
</select>
    </div>
    </div>
    <div class="col">
   Description
  <div class="mb-2">
      <textarea type="text" class="form-control" name='description' placeholder="(optional)"></textarea>
  </div>
    </div>
    </div>

<br>
<div class="row">
       <div class="col">

    Meeting starts at: Date
  <div class="mb-2">
    <input type="date" class="form-control" name='sdate'>
           </div>
    </div>
        <div class="col">

 Time
    <input type="time" class="form-control" name='stime'>
  </div>
    </div>
   <div class="row">
       <div class="col">

    Meeting expires at: Date
  <div class="mb-2">
    <input type="date" class="form-control" name='edate'>
           </div>
       </div>
        <div class="col">
   Time
     <div class="mb-2">

<input type="time" class="form-control" name='etime'>
            </div>
  </div>
    </div>
    <div class="row">
       <div class="col">
  <div class="mb-2 form-check">
   Meeting mode: &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="checkbox" class="form-check-input" value="y" name='check'>
    <label class="form-check-label" >Teachers only</label>
  </div>
        </div>
       <div class="col">

   Link for joining
   <div class="mb-2">
    <input type="text" class="form-control" name='link'>
  </div>
        </div>
    </div>
   
    <div class="mb-1 form-check">
  <button type="submit" name='submit' class="btn btn-primary">Submit</button>
    </div>
</form>
</div>
</div>
</div>


</body>
</html>

<?php

if(isset($_POST['submit'])){
    if($_POST['title']!=""&&$_POST['sdate']!=""&&$_POST['stime']!=""&&$_POST['edate']!=""&&$_POST['etime']!=""&&$_POST['link']!=""){
    $title=$_POST['title'];
    $description=$_POST['description'];
   $sdatetime = $_POST['sdate']." ".$_POST['stime'];
   $edatetime = $_POST['edate']." ".$_POST['etime'];
        
    if(isset ($_POST['check']))
        $mode = 'y';
    else
        $mode = 'n';
        
    $link=$_POST['link'];
    $id=$_SESSION['fac_id'];
    $cc_id=$_SESSION['cc_chair'];
    $group_id=$_SESSION['group_id'];
    

   $addmeeting=mysqli_query($connection,"INSERT INTO `meeting` (`id`, `group_id`, `chair`, `title`, `description`, `start_datetime`, `end_datetime`, `link`, `mode`) VALUES (NULL, '$group_id', ' $cc_id', '$title', '$description', '$sdatetime', '$edatetime', '$link', '$mode')");

   // if($_POST['file']!=""){



    $class_instructors=mysqli_query($connection,"select * from class_instructors where group_id=$group_id");
    while($row=mysqli_fetch_assoc($class_instructors)){
        
        $f_id=$row['fac_id'];
       echo $course=$row['course_id'];
        
        date_default_timezone_set('Asia/Kolkata');
        $current_time= date('Y-m-d h:i:s', time());
        
        
        if($title=='Zeroth class committee meeting'){
            addtofilestb($connection,'course plan',$current_time, $sdatetime, $f_id, $course, $group_id,'y','Zeroth');
            addtofilestb($connection,'evalution policy',$current_time, $sdatetime, $f_id, $course, $group_id,'y','Zeroth');
        }
        else if($title=='First class committee meeting'){
            
        }
        else if($title=='Midterm class committee meeting'){
            addtofilestb($connection,'attendance shortage report',$current_time, $sdatetime, $f_id, $course, $group_id,'y','Midterm');
            addtofilestb($connection,'aums mark report',$current_time, $sdatetime, $f_id, $course, $group_id,'y','Midterm');
            addtofilestb($connection,'obe file',$current_time, $sdatetime, $f_id, $course, $group_id,'y','Midterm');

        }
        else if($title=='Internal finalization class committee meeting'){
            addtofilestb($connection,'internal mark report',$current_time, $sdatetime, $f_id, $course, $group_id,'n','Internal finalization');
            addtofilestb($connection,'attendance shortage report',$current_time, $sdatetime, $f_id, $course, $group_id,'n','Internal finalization');

        }        
        else if($title=='Grading finalization class committee meeting'){
            
            $grade=mysqli_query($connection,"INSERT INTO `grade_finalizationcc` 
        (`id`, `fac_id`, `course_id`, `group_id`) 
        VALUES (NULL, '$f_id', '$course', '$group_id')");
        }
        
        
    }
    //}
        if($addmeeting){
        ?><script>alert("meeting scheduled succesfully!");
           location.replace("scheduleMeeting.php");
</script>
           <?php
            
    }
    }
    else{
                ?><script>alert("enter all nessessary information.");</script><?php

    }
}
    

?>
