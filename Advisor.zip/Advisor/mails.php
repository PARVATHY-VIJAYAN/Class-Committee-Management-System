<!DOCTYPE html>
<html lang="en">
<?php  session_start();
 include"header.php";?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Mails</title>

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">

</head>

<body id="page-top" >



                <div class="container-fluid mt-5">

                    <!-- Page Heading -->

                   
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Mails</h6>
                        </div>
                        <div class="card-body">
                           <form action="" method="post">
                            To:
                            <div class="mb-2">
                                <select name="to" class="btn btn-light" id="">
                                    <option value=""hidden>Faculties</option>
                                       <?php $ci=mysqli_query($connection,"select fac_id from class_instructors where group_id='".$_SESSION['group_id']."'");
                                                while($row=mysqli_fetch_assoc($ci)){
                                                    
                                        echo "<option value='".$row['fac_id']."'";
                                            
                                        $fac=mysqli_query($connection,"select fac_name from faculty where fac_id='".$row['fac_id']."'");
                                                    
                                        while($rows=mysqli_fetch_assoc($fac)){
                                            echo">".$row['fac_id'].". ".$rows['fac_name']."</option>";
                                                }
                                        }
                                        ?>
                                </select>
                            </div>
                            Message:
                            <div class="mb-2">
                                <textarea type="text" class="form-control" name='message'></textarea>
                            </div>
                             <div class="mb-1 form-check">
                                  <button type="submit" name='submit' class="btn btn-primary">Send</button>
                            </div>
                            <div class="mb-1 form-check">
                                  <button  class="btn btn-primary"><a style="color:white;text-decoration:none" href="mail_history.php">History</a></button>
                            </div>
                            </form>
                        </div>
                    </div>

                </div>

 <?php
    if(isset($_POST['submit']) && $_POST['to']!='' && $_POST['message']!=''){
        date_default_timezone_set('Asia/Kolkata');
        $current_time= date('Y-m-d', time());
        $cc=$_SESSION['cc_chair'];
        $fac=$_POST['to'];
        $addmail=mysqli_query($connection, "INSERT INTO `reminder` (`id`, `description`, `date`, `sender`, `receiver_id`, `readmsg`) VALUES (NULL, '".$_POST['message']."', '$current_time', '$cc', '$fac','n')" );
        if($addmail){
            ?>
            <script>alert("mail sent succesfully!");</script>
            <?php
        }
    }
    ?>


<?php include"footer.php";?>

</body>

</html>