<?php session_start();
    include"header.php";
?>
             
                <!-- End of Topbar -->
                <!-- Begin Page Content -->
                <div class="container-fluid mt-5">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Scheduled Meeting</h1>
                   <button class="btn btn-primary btn-user btn-block"><a style="color:white" href="scheduleMeeting.php">Schedule Meeting</a></button>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Upcoming meeting list</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Description</th>
                                            <th>Starts at</th>
                                            <th>Ends by</th>
                                            <th>Join</th>
                                            <th>Edit</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                       <?php
                                       $gid=$_SESSION['group_id']; 
                                        $meeting=mysqli_query($connection,"select * from meeting where group_id='$gid' && end_datetime >= CURRENT_TIMESTAMP order by start_datetime");
                                        while($rows=mysqli_fetch_assoc($meeting)){
                                            
                                            echo"<form method='get'><tr>";
                                            echo"<td><input class='form-control'value='".$rows['title']."'name='title'></td>";
                                            echo"<td><input class='form-control'value='".$rows['description']." 'name='description'> </td>";
                                            echo"<td><input input class='form-control' value='".$rows['start_datetime']."'name='stime'></td>";
                                            echo"<td><input input class='form-control' value='".$rows['end_datetime']."'name='etime'>
                                            <input hidden value='".$rows['id']."'name='id'></td>";
                                            echo"<td><button  ";
                                            date_default_timezone_set('Asia/Kolkata');
                                            $current_time= date('Y-m-d h:i:s', time());
                                            if(strtotime($current_time)<strtotime($rows['start_datetime']))
                                                echo" disabled class='btn btn-primary btn-user btn-block'>Join</button></td>";
                                            else{
                                            echo "class='btn btn-primary btn-user btn-block'><a style='color:white' target='blank' href='".$rows['link']."'>Join</a></button></td>";
                                            }
                                            echo"<td><input type='submit' class='btn btn-primary btn-user btn-block' value='Update'></td>";
                                            echo"</tr></form>";

                                        }
                                        
                                        if(isset($_GET['id'])){
                                        $title=$_GET['title'];
                                        $description=$_GET['description'];
                                        $stime=$_GET['stime'];
                                        $etime=$_GET['etime'];
                                        $id=$_GET['id'];
                          $update=mysqli_query($connection,"UPDATE `meeting` SET `end_datetime` = '$etime',`start_datetime`='$stime', `title` = '$title',`description` = '$description' WHERE `meeting`.`id` = $id");
                                            if($update){
                                                ?>
                                                <script>alert("updated!");
                                                location.replace("scheduled_meeting.php")</script>
                                                <?php
                                            }
                                        }
                                           ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
<?php include"footer.php";?>


</body>

</html>