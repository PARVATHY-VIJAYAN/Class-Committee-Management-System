<?php

include "header.php";
include "footer.php";

?>

<?php// session_start();?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>   CC Chair</title>
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link
        href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i"
        rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.css" rel="stylesheet">
    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
</head>
<body id="page-top">
    <!-- Page Wrapper -->
                 <div class="container-fluid">
        <!-- Sidebar -->
        
        <!-- End of Sidebar -->
        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <!-- Main Content -->
            <div id="content" class="ml-3">
                <!-- Topbar -->
               
                <!-- End of Topbar -->
  <h2 align="center">  </h2>
    
     <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.7.2/font/bootstrap-icons.css">
       <link href="vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css"> <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet"> <!-- Custom styles for this template--> <link href="css/sb-admin-2.css" rel="stylesheet"> 
       
       <br>
<style>
    .batch-text:hover + .Extra-Text 
    {
    display: block;
    }
    .Extra-Text {
    margin-top: auto;
    width: 150px;
    border: 1px solid #000000;
    padding: auto;
    font-size: 12px;
    display: none;
    }
</style><br>
<div class="row">
  
<?php
       
 if(isset($_GET['batch'])&&isset($_GET['group']) &&!isset($_GET['sem']))
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
                     
$semPath = '../file/'.$batch.'/'.$group;

if (is_dir($semPath)) {
    // Proceed with scanning and displaying folders
    $semfolders = scandir($semPath);

foreach ($semfolders as $sem) {
    if (is_dir($semPath . '/' . $sem) && $sem != '.' && $sem != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a style="text-decoration:none" href="files.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="align:center;">
                        <?php
                        echo "sem. ".substr($sem,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $sem;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
    
    
     if(isset($_GET['batch'])&&isset($_GET['group'])&&isset($_GET['sem']) && !isset($_GET['course']) )
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
     $sem=$_GET['sem'];
                     
$coursePath = '../file/'.$batch.'/'.$group.'/'.$sem;

if (is_dir($coursePath)) {
    // Proceed with scanning and displaying folders
    $coursefolders = scandir($coursePath);

foreach ($coursefolders as $course) {
    if (is_dir($coursePath . '/' . $course) && $course != '.' && $course != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a style="text-decoration:none" href="files.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>&course=<?php echo $course; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="align:center;">
                        <?php
                        echo substr($course,0,13);echo "...";
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $course;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
    
if(isset($_GET['batch'])&&isset($_GET['group'])&&isset($_GET['sem']) &&isset($_GET['course']) && !isset($_GET['fac']))
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
     $sem=$_GET['sem'];
     $course=$_GET['course'];
                     
$facPath = '../file/'.$batch.'/'.$group.'/'.$sem.'/'.$course;

if (is_dir($facPath)) {
    // Proceed with scanning and displaying folders
    $facfolders = scandir($facPath);

foreach ($facfolders as $fac) {
    if (is_dir($facPath . '/' . $fac) && $fac != '.' && $fac != '..') {
        ?>
         <div class="col-xs-6 pr-5">
    <a style="text-decoration:none" href="files.php?batch=<?php echo $batch; ?>&group=<?php echo $group; ?>&sem=<?php echo $sem; ?>&course=<?php echo $course; ?>&fac=<?php echo $fac; ?>">   
                        <span id="boot-icon" class="bi bi-folder-fill" style="font-size: 57px; border: 8px hidden; background-color: rgb(242, 242, 242); padding: 25px; border-radius: 17%; color: rgb(241, 200, 88);"></span> 
                        <br><br>
                        <p class="batch-text" style="align:center;">
                        <?php
                        echo substr($fac,0,13);
                        
                        ?>
                        </p>   </a>
                        <div class="Extra-Text">
                            <p>
                            <?php echo $fac;?>
                            </p>
                        </div>
                    </div><?php
    }
}
 }
      else {
    echo 'Directory does not exist.';
}
    }
    
    if(isset($_GET['batch'])&&isset($_GET['group'])&&isset($_GET['sem']) &&isset($_GET['course']) && isset($_GET['fac']))
 {
     $batch=$_GET['batch'];
     $group=$_GET['group'];
     $sem=$_GET['sem'];
     $course=$_GET['course'];
     $fac=$_GET['fac'];
    $folderPath ='../file/'.$batch.'/'.$group.'/'.$sem.'/'.$course.'/'.$fac;// Replace with the path to your folder

// Function to get the file icon based on its extension
function getFileIcon($extension)
{
    $iconPath = '../icons/'; // Replace with the path to your icon folder
    
    switch ($extension) {
        case 'txt':
            return $iconPath . 'text.png';
        case 'pdf':
            return $iconPath . 'pdf.png';
        case 'doc':
        case 'docx':
            return $iconPath . 'word.png';
        case 'xls':
        case 'xlsx':
            return $iconPath . 'excel.png';
        case 'ppt':
        case 'pptx':
            return $iconPath . 'ppt.png';
        case 'jpg':
        case 'jpeg':
        case 'png':
        case 'gif':
            return $iconPath . 'image.png';
        default:
            return $iconPath . 'else.png';
    }
}

// Get the files in the folder
$files = scandir($folderPath);
?>

        
                   <table class='table'>
                       <tr>
                           <th><h2 align='center'>FILES</h2></th>
                       </tr>
                       
                    

<?php
        
// Display files with icons
foreach ($files as $file) {
    if ($file !== '.' && $file !== '..') {
        $fileExtension = pathinfo($file, PATHINFO_EXTENSION);
        $icon = getFileIcon($fileExtension);
        echo '<tr><td>';?>
<a style="text-decoration:none" href="../file/<?php echo $batch; ?>/<?php echo $group; ?>/<?php echo $sem; ?>/<?php echo $course.'/'.$fac.'/'.$file;?>">
   <?php
                       echo '<img style="width:30px;height:30px;"  src="' . $icon . '" alt="File Icon">&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp'.$file;?> </a><?php echo'</td></tr>';
        
    }
}
    }
?>
</table>
                     </div></div></div></div>
                     
   
  
 