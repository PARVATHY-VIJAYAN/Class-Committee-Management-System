<?php 
session_start();
include"header.php";?>
                  
<!
<!-- ----------------------------------------------------------DataTales Example -->
    <div class="container-fluid mt-5">
                    <div class="card shadow mb-4">
                        <div class="card-body">
                           
   
                      
                           
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Name</th>
                                            <th>Mark</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                          <?php


        require_once "Classes/PHPExcel.php";
        $coursename = mysqli_query($connection,"select course_name from course where course_id = '".$_GET['g_course']."'");
          while($row = mysqli_fetch_assoc($coursename))
          {
            $c=$row['course_name'];
          }
        $facname = mysqli_query($connection,"select fac_name from faculty where fac_id = '".$_GET['fac_id']."'");
          while($row = mysqli_fetch_assoc($facname))
          {
            $f=$row['fac_name'];
          }
          
$path="../file/".$_SESSION['batch_name']."/".$_SESSION['group_name']."/".$_GET['sem']."/$c/".$_GET['fac_id']."_"."$f/".$_GET['f_name'];
       
                        
                                            $reader= PHPExcel_IOFactory::createReaderForFile($path);
                                            $excel_Obj = $reader->load($path); 
                                            $worksheet=$excel_Obj->getSheet('0');
                                            $lastRow = $worksheet->getHighestRow();
                                            $colomncount = $worksheet->getHighestDataColumn();
                                            $colomncount_number=PHPExcel_Cell::columnIndexFromString($colomncount);
                                            $pass = array();
                                            $fail = array();
                                            $absent= array();
                                            for($row=0;$row<=$lastRow;$row++)
                                            {
                                                echo "<tr>";
                                                for($col=0;$col<=$colomncount_number;$col++)
                                                {
                                                        if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()!="")
                                                        {
                                                            //finding outoff
                                                            if($col==2&&$row==1)
                                                            {
                                                                $outoff = substr($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue(),5);
                                                                echo "<th>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</th>";
                                                                
                                                            }
                                                            else if($col==0&&$row==1 || $col==1&&$row==1)
                                                            {
                                                                echo "<th>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</th>";
                                                                
                                                            }
                                                            else if($col==0 || $col==1)
                                                            {
                                                                 echo "<td>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</td>";
                                                            }
                                                            else
                                                            {
                                                                //ab
                                                                if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="ab"||$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="a"||$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()=="A")
                                                                {
                                                                     array_push($absent,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue());
                                                                    echo "<td bgcolor='#b3e6ff'>";                            
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }
                                                                //below 20 %
                                                                else if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()<=(($outoff*20)/100))
                                                                {
                                                                    array_push($fail,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue());
                                                                    
                                                                    echo "<td bgcolor='#ffcccc'>";                            
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }
                                                                //above 90 %
                                                                else if($worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue()>=(($outoff*90)/100))
                                                                {
                                                                array_push($pass,$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-2).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col-1).$row)->getValue(),$worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue());
                                                                    
                                                                echo "<td bgcolor='#bbff99'>";
                                                                echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                echo "</td>";
                                                                }
                                                                else
                                                                {
                                                                    echo "<td>";
                                                                    echo $worksheet->getCell(PHPExcel_Cell::stringFromColumnIndex($col).$row)->getValue();
                                                                    echo "</td>";
                                                                }

                                                            }
                       
                                                        }
		                                      }
		                                      echo "</tr>";
                                            }	?>
                   
                                    </tbody>
                                    </table>
                                </div>
                                   <!-- list out students above 90%-->
                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Students who got above 90%</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                                <th>Mark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($pass);$i=$i+3)
                                         {
                                             echo "<tr><td>".$pass[$i]."</td><td>".$pass[$i+1]."</td><td>".$pass[$i+2]."</td></tr>";
                                         }?>
                                        </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                                    
                                    
                                    <!-- list out students below 20%-->

                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Students who got below 20%</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                                <th>Mark</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($fail);$i=$i+3)
                                         {
                                             echo "<tr><td>".$fail[$i]."</td><td>".$fail[$i+1]."</td><td>".$fail[$i+2]."</td></tr>";
                                         }
                                        ?>
                                           </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                                    
                                    <!-- absentees-->
                                    <div class="card shadow mb-4">
                                    <div class="card-header py-3">
                                        <h6 class="m-0 font-weight-bold text-primary">Absentees</h6>
                                    </div>
                                    <div class="card-body">
                                    <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Roll number</th>
                                                <th>Name</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                         for($i=0;$i<count($absent);$i=$i+2)
                                         {
                                             echo "<tr><td>".$absent[$i]."</td><td>".$absent[$i+1]."</td></tr>";
                                         }?>
                                        </tbody>
                                    </table>
                                    </div>
                                    </div>
                                    </div>
                            </div>     
                            
                    </div>
                                   
                     

                     
                <!-- /.container-fluid -->
                
                        

</div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

  
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/chart.js/Chart.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/chart-area-demo.js"></script>
    <script src="js/demo/chart-pie-demo.js"></script>

</body>

</html>
<!----------------------------------------------------------------------->
                                            </div>
   
<?php include "footer.php";?>
