<!DOCTYPE html>
<html lang="en">
<?php
    include "../database.php";
    ?>
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Login</title>


    <!-- Custom styles for this template-->
    <link href="css/sb-admin-2.css" rel="stylesheet">

</head>

<body >

    <div class="container">

        <!-- Outer Row -->
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block pt-4 pl-4">
                                <img src="img/undraw_posting_photo.svg" width=500>
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Login</h1>
                                    </div>
                                    <form class="user" method="post">
                                        <div class="form-group">
                                            <input type="text" name='username'class="form-control form-control-user"
                                                id="username" required
                                                placeholder="Enter username...">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name='password' required class="form-control form-control-user"
                                                id="pass" placeholder="Password">
                                        </div>
                                        <input type='submit' name='submit'class="btn btn-primary btn-user btn-block">
                                    </form>
                                    <hr>
                                    <div class="text-center">
                                        <a class="small" href="forgot-password.html">Forgot Password?</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>

    </div>
<?php
  
   if(isset($_POST['submit'])&& $_POST['username']!="" &&$_POST['password']!=""){
       $id=$_POST['username'];
       $pw=$_POST['password'];
       $users=mysqli_query($connection,"select fac_id,password from faculty where fac_id='$id'");
       while($row=mysqli_fetch_assoc($users)){
           $p=$row['password'];
           $user=$row['fac_id'];
       }
       if($p==$pw &&$id==$user){
           session_start();
           $_SESSION['fac_id']=$id;
             //header('Location: '."../faculty/dashboard.php");
                       ?>
            <script>location.replace("../faculty/index.php")</script>
            <?php
       }
       else{
            ?>
            <script>alert("invalid password or username");</script>
            <?php 
       }
   }
   
   ?>
    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>


<?php

?>
