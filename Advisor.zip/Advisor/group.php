<?php
session_start();
include"header.php";

?><div class="container-fluid mt-5">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Group: <?php 
                        $groupname=mysqli_query($connection,"select name from group_details where group_id='".$_SESSION['group_id']."'");while($row=mysqli_fetch_assoc($groupname))echo $row['name'];?></h1>
                         
                                
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary ">CLASS INSTRUCTORS LIST</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                               <form method="get">
                                            <select name="fac" class="btn btn-light" id="">
                                                <option value=""hidden>Faculties</option>
                                               <?php $faculties=mysqli_query($connection,"select fac_id,fac_name from faculty");
                                                        while($row=mysqli_fetch_assoc($faculties)){
                                                echo "<option value='".$row['fac_id']."'>".$row['fac_id'].". ".$row['fac_name']."</option>";
                                                        }?>
                                            </select>
                                            <select name="course" class="btn btn-light" id="">
                                                <option value=""hidden>Courses</option>
                                               <?php $courses=mysqli_query($connection,"select course_id,course_name from course where batch_id='".$_SESSION['batch_id']."'");
                                                        while($row=mysqli_fetch_assoc($courses)){
                                                echo "<option value='".$row['course_id']."'>".$row['course_id'].". ".$row['course_name']."</option>";
                                                        }?>
                                            </select>
                                            <input type=submit class ="btn btn-primary" name=cisubmit value=Add>
                                            </form>
<?php
if(isset($_GET['cisubmit'])){
    if($_GET['fac']!=""&&$_GET['course']!=""){

        try{
                $add=mysqli_query($connection,"insert into class_instructors (group_id,fac_id,course_id)values('".$_SESSION['group_id']."','".$_GET['fac']."','".$_GET['course']."')");
                $coursen=mysqli_query($connection,"select course_name from course where course_id='".$_GET['course']."'");
            
                while($row=mysqli_fetch_assoc($coursen)){
                    $course = $row['course_name'];
                }
            $semno=mysqli_query($connection,"select sem from course where course_id='".$_GET['course']."'");
            
                while($row=mysqli_fetch_assoc($semno)){
                    $sem = $row['sem'];
                }
            
                $facn=mysqli_query($connection,"select fac_name from faculty where fac_id='".$_GET['fac']."'");
            
                while($row=mysqli_fetch_assoc($facn)){
                    $facname = $row['fac_name'];
                }

            if (!is_dir('../file/'.$_SESSION['batch_name'].'/'.$_SESSION['group_name'].'/'.$sem.'/'.$course.'/'.$_GET['fac']."_".$facname)) 
            {
             mkdir('../file/'.$_SESSION['batch_name'].'/'.$_SESSION['group_name'].'/'.$sem.'/'.$course.'/'.$_GET['fac']."_".$facname, 0777, true);
            }
            else
            {
                echo "<script>alert('Folder already exists');</script>";
            }
        }
        catch(Exception $e){  }
        ?>
        <script>//location.replace("group.php");</script><?php
    }
}
?>
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Faculty id</th>
                                            <th>Class Instructors</th>
                                            <th>Course</th>
                                            <th>Delete</th>

                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                    
                                    <?php $class_inst=mysqli_query($connection,"select fac_id,course_id from class_instructors where group_id='".$_SESSION['group_id']."'");
                                        while($row=mysqli_fetch_assoc($class_inst)){
                                            echo"<tr>";
                                            $fac=mysqli_query($connection,"select fac_name,fac_id from faculty where fac_id='".$row['fac_id']."'");
                                            while($rows=mysqli_fetch_assoc($fac)) {
                                                echo "<td> ".$rows['fac_id']."</td>";
                                                echo "<td>".$rows['fac_name']."</td>";}
                                            $crs=mysqli_query($connection,"select course_name,course_id from course where course_id='".$row['course_id']."'");
                                            while($rows=mysqli_fetch_assoc($crs)) 
                                                echo "<td> ".$rows['course_name']."</td>";
                                                echo"<td><button class='btn btn-primary'><a style='color:white' href='group.php?dfac=".$row['fac_id']."&dcour=".$row['course_id']."&dgrp=".$_SESSION['group_id']."'>delete</a></button></td>";
                                                echo"</tr>";
                                        }
                                        if(isset ($_GET['dfac'])){
                                            $delfac=mysqli_query($connection,"delete from class_instructors where group_id='".$_GET['dgrp']."' && fac_id='".$_GET['dfac']."' && course_id='".$_GET['dcour']."'");
                                            ?>
                                                    <script>location.replace("group.php");</script><?php
                                        }
                                        ?>
                                        
                                        
                                    </tbody>
                                    
                                </table >
                         <h6 class="m-0 font-weight-bold text-primary">STUDENT REPRESENTATIVES</h6>

                                    <table class="table table-bordered" >
                                    <thead>
                                        <tr>
                                            <th>Student ID</th>
                                            <th>Class Reps</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    
                                    <?php $student=mysqli_query($connection,"select name,stud_id,access from student where group_id='".$_SESSION['group_id']."'");
                                        while($row=mysqli_fetch_assoc($student)){
                                             echo "<tr><td>".$row['stud_id']."</td>";
                                             echo "<td>".$row['name']."</td>";
                                             if($row['access']=='allow'){
                                                 echo"<td><a href='group.php?st=".$row['stud_id']."&a=deny'><i class='fa fa-check' style='font-size:25px;color:blue'></i></a></td>";
                                             }
                                            else{
                                               echo" <td><a href='group.php?st=".$row['stud_id']."&a=allow'><i class='fa fa-close' style='font-size:25px;color:blue'></i></a></td>";
                                            }
                                            echo"</tr>";

                                        }
                                        ?>
                                        
                                        
                                    </tbody>
                                </table>
                <h6 class="m-0 font-weight-bold text-primary">NON INSTRUCTOR FACULTIES</h6>

                                           <?php
                                if(isset($_GET['st'])){
                                    $stud=mysqli_query($connection,"update student set access='".$_GET['a']."' where stud_id='".$_GET['st']."'");
                                    
                                ?>
                                    <script>location.replace("group.php");</script><?php
                                }
                                ?>
                                  
                                  <form method="get">
                                   <select name="nifac" class="btn btn-light" id="">
                                                <option value=""hidden>Faculties</option>
                                               <?php $faculties=mysqli_query($connection,"select fac_id,fac_name from faculty");
                                                        while($row=mysqli_fetch_assoc($faculties)){
                                                echo "<option value='".$row['fac_id']."'>".$row['fac_id'].". ".$row['fac_name']."</option>";
                                                        }?>
                                        </select>  
                                <input type=submit class ="btn btn-primary" name=nisubmit value=Add>

                                </form>       
                                <table class="table table-bordered" >
                                    <thead>
                                        <tr>
                                            <th>Faculty ID</th>
                                            <th>non Instructors</th>
                                            <th>Delete</th>
                                        </tr>
                                    </thead>
                                    <?php
                                    if(isset($_GET['nisubmit'])){
                                        if($_GET['nifac']!=""){
                                            try{
                                             $addnifac=mysqli_query($connection,"insert into non_instructors (group_id,fac_id)values('".$_SESSION['group_id']."','".$_GET['nifac']."')");
                                            }
                                            catch(Exception $e){}
                                            ?>
                                                    <script>location.replace("group.php");</script><?php
                                        }
                                    }
                                    ?>
                                    <tbody>
                                            <?php
                                        $nifac=mysqli_query($connection,"select * from non_instructors where group_id='".$_SESSION['group_id']."'");
                                        while($row=mysqli_fetch_assoc($nifac)){
                                            echo"<tr>";
                                            echo"<td>".$row['fac_id']."</td>";
                                        $fac=mysqli_query($connection,"select fac_name,fac_id from faculty where fac_id='".$row['fac_id']."'");
                                        while($rows=mysqli_fetch_assoc($fac)) 
                                            echo "<td>".$rows['fac_name']."</td>";
                                            echo"<td><button class='btn btn-primary'><a style='color:white' href='group.php?dnifac=".$row['fac_id']."&dgrp=".$_SESSION['group_id']."'>delete</a></button></td>";
                                            echo"</tr>";
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                <?php
                                if(isset ($_GET['dnifac'])){
                                            $delnifac=mysqli_query($connection,"delete from non_instructors where group_id='".$_GET['dgrp']."' && fac_id='".$_GET['dnifac']."'");
                                            ?>
                                                    <script>location.replace("group.php");</script><?php
                                        }
                                ?>
                            </div>
                        </div>
                    </div>

                </div>

