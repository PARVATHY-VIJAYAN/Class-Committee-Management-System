<!--end all the session -->


<?php header("Location: login.php");?>
<a href="../faculty/login.php"></a>